// imports
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AppComponent} from './app.component';
import {AppRoutingModule} from './app-routing.module';
import {HttpModule} from '@angular/http';
import { FormsModule }   from '@angular/forms';
import {ProjectComponent} from './components/projects/project.component'
import {UserComponent} from './components/user/user.component'


// @NgModule decorator with its metadata
@NgModule({
  imports: [BrowserModule,AppRoutingModule,HttpModule,FormsModule],
  declarations:[AppComponent,ProjectComponent,UserComponent],
  bootstrap:[AppComponent]
})
export class AppModule { }