import {Component} from '@angular/core';
import {ProjectService} from '../../services/project.service'
import {Project} from '../../project'


@Component({
    moduleId:module.id,
    selector:'project',
    templateUrl:'project.component.html',
    styleUrls:['../../styles.css'],
    providers:[ProjectService]
})

export class ProjectComponent{
    projects:Project[];
    
    constructor(private projectService:ProjectService){
       this.projectService.getProject().subscribe(projects=>{
           this.projects=projects;
       });

    }
    
    
    
}