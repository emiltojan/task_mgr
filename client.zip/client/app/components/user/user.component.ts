import {Component} from '@angular/core';
import {UserService} from '../../services/user.service';
import {User} from '../../user';

@Component({
    moduleId:module.id,
    selector:'user',
    templateUrl:'user.component.html',
    styleUrls:['../../styles.css'],
    providers:[UserService]
})

export class UserComponent{
    users:User[];
    constructor(private userService:UserService){
        this.userService.getUser().subscribe(users=>{
            this.users = users;
        })
    }
}