import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {ProjectComponent} from './components/projects/project.component'
import {UserComponent} from './components/user/user.component'


const routes: Routes = [
  { path: '', redirectTo: '/project', pathMatch: 'full' },
  { path: 'project', component: ProjectComponent },
  { path: 'user', component: UserComponent}
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}