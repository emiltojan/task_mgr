"use strict";
var Project = (function () {
    function Project() {
    }
    return Project;
}());
exports.Project = Project;
//# sourceMappingURL=project.js.map