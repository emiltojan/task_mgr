export class Project{
    _id:number;
    proj_name:string;
    tasks:string[];
}