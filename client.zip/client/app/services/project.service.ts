import {Http,Headers} from '@angular/http';
import 'rxjs/add/operator/map';
import {Injectable} from '@angular/core';

@Injectable()

export class ProjectService{
    constructor(private http:Http){
        console.log("Project Service Initialized");
         }
         
   getProject(){
       return this.http.get('/api/project')
         .map(res=>res.json());
   }      
    
}


