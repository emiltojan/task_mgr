import {Http,Headers} from '@angular/http';
import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';

@Injectable()

export class UserService{
    constructor(private http:Http){
        console.log('User service initialized');
        }
        
 getUser(){
     return this.http.get('/api/user')
        .map(res=>res.json());
 }       
}