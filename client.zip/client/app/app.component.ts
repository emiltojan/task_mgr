import {Component} from '@angular/core';
import {ProjectService} from './services/project.service'

@Component({
    moduleId:module.id,
    selector:'my-app',
    templateUrl:'app.component.html',
    styleUrls:['styles.css'],
    providers:[ProjectService]
})

export class AppComponent{}